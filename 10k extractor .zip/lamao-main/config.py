import os

class Config(object):
    # Telegram Bot ka token
    BOT_TOKEN = "7632724382:AAH8j09VwOCeQd2THldBjEbw5-T8WNOBOKI"
    # Telegram API ki ID
    API_ID = "21537501"
    API_HASH = "02d8ef0eae2926ec4fd0cbff05ec0737"
    ADMIN_ID = [7891840370]
    # MongoDB database ka URL
    DB_URL = "mongodb+srv://bnnnndrrr:S3qEHo4sxhy4D7w5@cluster0.r1d1hvh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
    # Database ka naam
    DB_NAME = "jaipal"
    # Text log channel ki ID
    TXT_LOG = "-1002625911951"
    # Authentication log channel ki ID
    AUTH_LOG = "-1002563287858"
    # Hit log channel ki ID
    HIT_LOG = "-1002563287858"
    # DRM dump channel ki ID
    DRM_DUMP = "-1002563287858"
    # Main channel ki ID
    CHANNEL = "-1002625911951"
    # Channel ka link
    CH_URL = "https://t.me/+jrIvAHyJsIBhZDc1"
    # Bot ke owner ka Telegram link
    OWNER = "https://t.me/anyone"
    # Thumbnail image ka URL
    THUMB_URL = "https://i.ibb.co/Mv0cMh6/67e3ea172e5c6.jpg" #Replace by with your Thumb URL
     #Replace by with your Thumb URL
