START = """
<b><u>👋 Hello {}, I'm Txt Extractor Bot at your service. 🤖</u>

To start extracting URLs, simply send /app. 📲

<blockquote><i>🔓 I support over 100+ apps for seamless URL extraction.
📥 After extracting the URLs, you can easily download the videos/pdfs using any of my Uploader Bot.⏬</blockquote></i>

<u>For any queries, contact [Admin](https://t.me/USERNAME)</u></b>
"""

APP = """
<b><i>👋 Hey there! I'm your Txt Extractor bot!🤖</i>


<blockquote>🚨 If you encounter any issues or can't extract any text file, just contact your [Admin](https://t.me/USERNAME).

💬 Got an app you'd like to add? Feel free to reach out to me anytime!</blockquote>


<i>👇 Choose an option below and let's get started!</i></b>
"""

UPGRADE ="""
<b><u>Hey👋, Choose Your Plan Below:-</u>



<i>🆓====FREE PLAN USER====🆓</i>
<blockquote>🔍 Only extract video URLs from APPX & Classplus apks!</blockquote>


<i>🤑====VIP PLAN USER====🤑</i>
<blockquote>🕵🏻‍♀️ Unlimited URL extraction for 1 month only For Few Apks!
❌ Txt-to-Video (Non-DRM) bot is not available in this plan.</blockquote>
<blockquote>💵 Price: ₹800 for 28 days</blockquote>



<i>🦁====PRO PLAN USER====🦁</i>
<blockquote>🔓 Extract URLs of Special Apps!
 🔑Extract only 5 batch URLs/per day without needing any ID or password!
✅ Enjoy Txt-to-Video (Non-DRM) bot with this plan.</blockquote>
<blockquote>💵 Price: ₹1000 for 10 days (or) ₹2000 for 28 days</blockquote>



<i>👑====LEGEND PLAN USER====👑</i>
<blockquote>🗿Everything Unlimited</blockquote>
<blockquote>🚀You get seprate Non-Drm Bot</blockquote>
<blockquote>💵 Price: ₹2500 for 28 days</blockquote>


<i>Upgrade now and take your experience to the next level! 🚀</i></b>
"""

V = """<b><i>🤑====VIP PLAN USER====🤑</i>
🕵🏻‍♀️ Unlimited URL extraction for 1 month only For Few Apk!
❌ Txt-to-Video (Non-DRM) bot is not available in this plan.</b>
"""

P = """<i><b>🦁====PRO PLAN USER====🦁</i>
🔓 Extract URLs of Special Apps!
 🔑Extract only 5 batches URLs Per Day without needing any ID or password!
✅ Enjoy Txt-to-Video (Non-DRM) bot with this plan.</b>
"""

L = """<i><b>👑====LEGEND PLAN USER====👑</i>
🗿You Can extract Unlimited Txts
🚀You get seprate Non-Drm Bot</b>
"""

auth = """
<b>🎉 Congrats [{}](tg://openmessage?user_id={}) for gaining access to Txt Extractor Bot! 🎉


<i>Your have access to the bot as a:</i>

{}

<u><i>🚀Enjoy your access for {} days!</u></i>


If you need any assistance, feel free to contact [Admin](https://t.me/USERNAME)</b>
"""
